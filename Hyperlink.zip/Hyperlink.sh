#!/bin/bash

declare -A cache

cache_func() {
    local arg="$1"
    
    if [[ ! ${cache[$arg]} ]]; then
        # Simulating expensive operation
        echo "Computing result for $arg" >&2
        
        sleep 2   # Wait (simulate long computation)
        
	    let res=$arg*10   # the heavy processing function result that we want to store.
	    
    	# Store results into our 'Cache'
    	cache["$arg"]=$res;
	fi
    
	return ${cache[$ar]}
}

for i in {0..5}; do 
	echo $( cache_func "$i")
done;